package com.wordcount;

import java.io.*;
import java.nio.charset.StandardCharsets;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.wltea.analyzer.core.IKSegmenter;
import org.wltea.analyzer.core.Lexeme;

public class TopNMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    private final static IntWritable ONE = new IntWritable(1);
    private final Text word = new Text();
    
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        // 使用IK分词器进行中文分词
        byte[] bt = value.getBytes();
        InputStream ip = new ByteArrayInputStream(bt);
        Reader read = new InputStreamReader(ip, StandardCharsets.UTF_8);
        IKSegmenter iks = new IKSegmenter(read, true);
        Lexeme t;
        while ((t = iks.next()) != null) {
            // 移除长度限制，统计所有词语包括单个字
            // 可以选择添加其他过滤条件，例如过滤标点符号等
            String lexeme = t.getLexemeText();
            if (isChineseCharOrLetter(lexeme)) {
                word.set(lexeme);
                context.write(word, ONE);
            }
        }
    }
    
    /**
     * 判断字符串是否由汉字或字母组成
     * 用于过滤掉标点符号、数字等
     */
    private boolean isChineseCharOrLetter(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        
        for (char c : str.toCharArray()) {
            // 检查是否是汉字（基本汉字范围：[\u4e00-\u9fa5]）
            // 或者是英文字母
            if (!Character.isLetterOrDigit(c) && !(c >= '\u4e00' && c <= '\u9fa5')) {
                return false;
            }
        }
        return true;
    }
} 