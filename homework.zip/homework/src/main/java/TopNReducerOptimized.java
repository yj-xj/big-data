package com.wordcount;

import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * 优化版的TopNReducer，使用WordFrequencyPair解决词频相同导致的覆盖问题
 */
public class TopNReducerOptimized extends Reducer<Text, IntWritable, Text, IntWritable> {
    private TreeMap<WordFrequencyPair, Integer> topWords;
    private final int TOP_N = 100; // 保存前100个高频词

    @Override
    protected void setup(Context context) {
        // 初始化TreeMap，用于存储词频对象和对应的词频
        topWords = new TreeMap<>();
    }

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) {
        // 统计每个词的总频率
        int frequency = 0;
        for (IntWritable value : values) {
            frequency += value.get();
        }
        
        // 创建WordFrequencyPair对象，作为TreeMap的键
        WordFrequencyPair pair = new WordFrequencyPair(frequency, key.toString());
        topWords.put(pair, frequency);
        
        // 如果TreeMap中的词超过了TOP_N，则删除频率最低的词
        if (topWords.size() > TOP_N) {
            topWords.remove(topWords.firstKey());
        }
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        // 倒序输出结果，频率高的排在前面
        NavigableMap<WordFrequencyPair, Integer> descendingMap = topWords.descendingMap();
        for (Map.Entry<WordFrequencyPair, Integer> entry : descendingMap.entrySet()) {
            WordFrequencyPair pair = entry.getKey();
            int frequency = entry.getValue();
            context.write(new Text(pair.getWord()), new IntWritable(frequency));
        }
    }
} 