package com.wordcount;

import java.util.Objects;

/**
 * 自定义辅助类，用于保存词频和词语
 * 解决词频相同导致的TreeMap覆盖问题
 */
public class WordFrequencyPair implements Comparable<WordFrequencyPair> {
    private final int frequency;
    private final String word;

    public WordFrequencyPair(int frequency, String word) {
        this.frequency = frequency;
        this.word = word;
    }

    public int getFrequency() {
        return frequency;
    }

    public String getWord() {
        return word;
    }

    @Override
    public int compareTo(WordFrequencyPair other) {
        // 先按词频比较，如果相同则按词语字典序比较
        if (this.frequency != other.frequency) {
            return this.frequency - other.frequency;
        } else {
            return this.word.compareTo(other.word);
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        WordFrequencyPair other = (WordFrequencyPair) obj;
        return frequency == other.frequency && Objects.equals(word, other.word);
    }

    @Override
    public int hashCode() {
        return Objects.hash(frequency, word);
    }
} 