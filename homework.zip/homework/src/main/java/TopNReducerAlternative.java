package com.wordcount;

import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * 替代实现的TopNReducer，使用HashMap和排序方式实现TopN
 */
public class TopNReducerAlternative extends Reducer<Text, IntWritable, Text, IntWritable> {
    private HashMap<String, Integer> rawMap;
    private final int TOP_N = 100; // 保存前100个高频词

    @Override
    protected void setup(Context context) {
        // 初始化HashMap，用于存储所有词及其频率
        rawMap = new HashMap<>();
    }

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) {
        // 统计每个词的总频率
        int sum = 0;
        for (IntWritable value : values) {
            sum += value.get();
        }
        
        // 直接将词和词频存入HashMap
        rawMap.put(key.toString(), sum);
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        // 将HashMap转换为List，便于排序
        List<Map.Entry<String, Integer>> entryList = new ArrayList<>(rawMap.entrySet());
        
        // 使用Collections.sort对List进行排序，按词频降序排列
        Collections.sort(entryList, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> entry1, Map.Entry<String, Integer> entry2) {
                // 首先按词频降序排序
                int freq1 = entry1.getValue();
                int freq2 = entry2.getValue();
                if (freq1 != freq2) {
                    return freq2 - freq1;
                }
                // 如果词频相同，则按词语字典序排序，保证输出稳定性
                return entry1.getKey().compareTo(entry2.getKey());
            }
        });

        // 输出前TOP_N个高频词
        int count = 0;
        for (Map.Entry<String, Integer> entry : entryList) {
            if (count < TOP_N) {
                context.write(new Text(entry.getKey()), new IntWritable(entry.getValue()));
                count++;
            } else {
                break;
            }
        }
    }
} 