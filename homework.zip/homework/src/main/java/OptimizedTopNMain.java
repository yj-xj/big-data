package com.wordcount;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * 使用优化版的Reducer的主程序入口
 */
public class OptimizedTopNMain {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: OptimizedTopNWordCount <input path> <output path>");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        // 设置UTF-8编码
        conf.set("mapreduce.job.queuename", "default");
        conf.set("mapreduce.map.output.compress", "false");
        conf.set("mapreduce.output.fileoutputformat.compress", "false");
        conf.set("io.serializations", "org.apache.hadoop.io.serializer.JavaSerialization,org.apache.hadoop.io.serializer.WritableSerialization");

        // 可以选择使用哪种方式实现的Reducer
        boolean useWordFrequencyPair = true; // 设置为true使用WordFrequencyPair方式，false使用HashMap排序方式
        
        Job job = Job.getInstance(conf, "Optimized Chinese Word Count Top 100");
        job.setJarByClass(OptimizedTopNMain.class);

        // 设置Mapper类
        job.setMapperClass(TopNMapper.class);
        
        // 根据选择设置Reducer类
        if (useWordFrequencyPair) {
            job.setReducerClass(TopNReducerOptimized.class);
            System.out.println("Using WordFrequencyPair optimization method.");
        } else {
            job.setReducerClass(TopNReducerAlternative.class);
            System.out.println("Using HashMap sorting optimization method.");
        }

        // 设置Combiner
        job.setCombinerClass(TopNCombiner.class);

        // 设置Map输出的键值类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);

        // 设置Reduce输出的键值类型
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        // 设置输入和输出路径
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        // 等待作业完成并打印统计信息
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
} 