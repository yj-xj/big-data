package com.wordcount;

import java.io.*;
import java.nio.charset.StandardCharsets;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.wltea.analyzer.core.IKSegmenter;
import org.wltea.analyzer.core.Lexeme;

public class TopNMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    private final static IntWritable ONE = new IntWritable(1);
    private final Text word = new Text();
    
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        // 使用IK分词器进行中文分词
        byte[] bt = value.getBytes();
        InputStream ip = new ByteArrayInputStream(bt);
        Reader read = new InputStreamReader(ip, StandardCharsets.UTF_8);
        IKSegmenter iks = new IKSegmenter(read, true);
        Lexeme t;
        while ((t = iks.next()) != null) {
            // 过滤掉长度小于2的词（通常是标点符号或单个字符）
            if (t.getLexemeText().length() >= 2) {
                word.set(t.getLexemeText());
                context.write(word, ONE);
            }
        }
    }
} 