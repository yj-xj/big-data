package com.wordcount;

import java.io.*;
import java.nio.charset.StandardCharsets;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.wltea.analyzer.core.IKSegmenter;
import org.wltea.analyzer.core.Lexeme;

public class TopNMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    private final static IntWritable ONE = new IntWritable(1);
    private final Text word = new Text();
    
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        // 使用IK分词器进行中文分词
        byte[] bt = value.getBytes();
        InputStream ip = new ByteArrayInputStream(bt);
        Reader read = new InputStreamReader(ip, StandardCharsets.UTF_8);
        IKSegmenter iks = new IKSegmenter(read, true);
        Lexeme t;
        while ((t = iks.next()) != null) {
            // 获取分词结果，不做长度限制
            String lexeme = t.getLexemeText();
            // 只过滤掉特殊符号和标点符号
            if (isValidTerm(lexeme)) {
                word.set(lexeme);
                context.write(word, ONE);
            }
        }
    }
    
    /**
     * 判断分词是否有效（过滤掉纯标点符号和特殊字符）
     */
    private boolean isValidTerm(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        
        // 至少包含一个汉字、英文字母或数字
        for (char c : str.toCharArray()) {
            if (Character.isLetterOrDigit(c) || (c >= '\u4e00' && c <= '\u9fa5')) {
                return true;
            }
        }
        return false;
    }
} 