package com.wordcount;

import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class TopNReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
    private TreeMap<Integer, List<String>> topWords;
    private final int TOP_N = 100; // 保存前100个高频词

    @Override
    protected void setup(Context context) {
        // 初始化TreeMap，用于存储词频和对应的词
        // 使用List<String>作为值，处理词频相同的情况
        topWords = new TreeMap<>();
    }

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) {
        // 统计每个词的总频率
        int frequency = 0;
        for (IntWritable value : values) {
            frequency += value.get();
        }
        
        // 将词频作为key，词作为value存入TreeMap
        if (!topWords.containsKey(frequency)) {
            topWords.put(frequency, new ArrayList<>());
        }
        topWords.get(frequency).add(key.toString());
        
        // 如果TreeMap中的词超过了TOP_N，则删除频率最低的词
        int totalWords = 0;
        for (List<String> words : topWords.values()) {
            totalWords += words.size();
        }
        
        // 如果总词数超过TOP_N，则移除频率最低的词直到总词数不超过TOP_N
        while (totalWords > TOP_N && !topWords.isEmpty()) {
            int lowestFreq = topWords.firstKey();
            List<String> lowestFreqWords = topWords.get(lowestFreq);
            
            if (totalWords - lowestFreqWords.size() >= TOP_N) {
                // 可以移除整个频率组
                topWords.remove(lowestFreq);
                totalWords -= lowestFreqWords.size();
            } else {
                // 只需要移除部分词
                int toRemove = totalWords - TOP_N;
                for (int i = 0; i < toRemove; i++) {
                    lowestFreqWords.remove(lowestFreqWords.size() - 1);
                }
                totalWords = TOP_N;
            }
        }
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        // 倒序输出结果，频率高的排在前面
        NavigableMap<Integer, List<String>> descendingMap = topWords.descendingMap();
        for (Map.Entry<Integer, List<String>> entry : descendingMap.entrySet()) {
            int frequency = entry.getKey();
            List<String> words = entry.getValue();
            
            // 对每个频率相同的词进行排序，保持结果的确定性
            Collections.sort(words);
            for (String word : words) {
                context.write(new Text(word), new IntWritable(frequency));
            }
        }
    }
} 